export const resizeImages = [2048, 2048];
export const OUTPUT_path = './output/';
